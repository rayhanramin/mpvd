/* -*- Mode: C++; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */
/* vim: set ts=4 sw=4 et tw=99 ft=cpp: */
/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

#include "FilteringWrapper.h"
#include "AccessCheck.h"
#include "WaiveXrayWrapper.h"
#include "ChromeObjectWrapper.h"
#include "XrayWrapper.h"
#include "WrapperFactory.h"

#include "XPCWrapper.h"

#include "jsapi.h"

using namespace js;

namespace xpc {

template 
FilteringWrapper::FilteringWrapper(unsigned flags) : Base(flags)
{
}

template 
FilteringWrapper::~FilteringWrapper()
{
}

template 
static bool
Filter(JSContext *cx, JSObject *wrapper, AutoIdVector &props)
{
    size_t w = 0;
    for (size_t n = 0; n < props.length(); ++n) {
        jsid id = props[n];
        if (Policy::check(cx, wrapper, id, Wrapper::GET))
            props[w++] = id;
        else if (JS_IsExceptionPending(cx))
            return false;
    }
    props.resize(w);
    return true;
}

template 
static bool
FilterSetter(JSContext *cx, JSObject *wrapper, jsid id, js::PropertyDescriptor *desc)
{
    bool setAllowed = Policy::check(cx, wrapper, id, Wrapper::SET);
    if (!setAllowed) {
        if (JS_IsExceptionPending(cx))
            return false;
        desc->setter = nullptr;
    }
    return true;
}

template 
bool
FilteringWrapper::getPropertyDescriptor(JSContext *cx, JSObject *wrapper, jsid id,
                                                      bool set, js::PropertyDescriptor *desc)
{
    if (!Base::getPropertyDescriptor(cx, wrapper, id, set, desc))
        return false;
    return FilterSetter(cx, wrapper, id, desc);
}

template 
bool
FilteringWrapper::getOwnPropertyDescriptor(JSContext *cx, JSObject *wrapper, jsid id,
                                                         bool set, js::PropertyDescriptor *desc)
{
    if (!Base::getOwnPropertyDescriptor(cx, wrapper, id, set, desc))
        return false;
    return FilterSetter(cx, wrapper, id, desc);
}

template 
bool
FilteringWrapper::getOwnPropertyNames(JSContext *cx, JSObject *wrapper, AutoIdVector &props)
{
    return Base::getOwnPropertyNames(cx, wrapper, props) &&
           Filter(cx, wrapper, props);
}

template 
bool
FilteringWrapper::enumerate(JSContext *cx, JSObject *wrapper, AutoIdVector &props)
{
    return Base::enumerate(cx, wrapper, props) &&
           Filter(cx, wrapper, props);
}

template 
bool
FilteringWrapper::keys(JSContext *cx, JSObject *wrapper, AutoIdVector &props)
{
    return Base::keys(cx, wrapper, props) &&
           Filter(cx, wrapper, props);
}

template 
bool
FilteringWrapper::iterate(JSContext *cx, JSObject *wrapper, unsigned flags, Value *vp)
{
    // We refuse to trigger the iterator hook across chrome wrappers because
    // we don't know how to censor custom iterator objects. Instead we trigger
    // the default proxy iterate trap, which will ask enumerate() for the list
    // of (censored) ids.
    return js::BaseProxyHandler::iterate(cx, wrapper, flags, vp);
}

template 
bool
FilteringWrapper::enter(JSContext *cx, JSObject *wrapper, jsid id,
                                      Wrapper::Action act, bool *bp)
{
    if (!Policy::check(cx, wrapper, id, act)) {
        if (JS_IsExceptionPending(cx)) {
            *bp = false;
            return false;
        }
        JSAutoCompartment ac(cx, wrapper);
        *bp = Policy::deny(cx, id, act);
        return false;
    }
    *bp = true;
    return Base::enter(cx, wrapper, id, act, bp);
}

#define SOW FilteringWrapper
#define SCSOW FilteringWrapper
#define XOW FilteringWrapper, \
                             CrossOriginAccessiblePropertiesOnly>
#define DXOW   FilteringWrapper
#define NNXOW FilteringWrapper
#define LW    FilteringWrapper, \
                               LocationPolicy>
#define XLW   FilteringWrapper, \
                               LocationPolicy>
#define CW FilteringWrapper
#define XCW FilteringWrapper
template<> SOW SOW::singleton(WrapperFactory::SCRIPT_ACCESS_ONLY_FLAG |
                              WrapperFactory::SOW_FLAG);
template<> SCSOW SCSOW::singleton(WrapperFactory::SCRIPT_ACCESS_ONLY_FLAG |
                                  WrapperFactory::SOW_FLAG);
template<> XOW XOW::singleton(WrapperFactory::SCRIPT_ACCESS_ONLY_FLAG);
template<> DXOW DXOW::singleton(WrapperFactory::SCRIPT_ACCESS_ONLY_FLAG);
template<> NNXOW NNXOW::singleton(WrapperFactory::SCRIPT_ACCESS_ONLY_FLAG);
template<> LW  LW::singleton(WrapperFactory::SHADOWING_FORBIDDEN);
template<> XLW XLW::singleton(WrapperFactory::SHADOWING_FORBIDDEN);

template<> CW CW::singleton(0);
template<> XCW XCW::singleton(0);

template class SOW;
template class XOW;
template class DXOW;
template class NNXOW;
template class LW;
template class XLW;
template class ChromeObjectWrapperBase;
}
